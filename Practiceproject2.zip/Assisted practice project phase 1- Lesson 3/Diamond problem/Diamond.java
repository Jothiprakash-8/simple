package pk9;
interface First 
{  
    default void display() 
    { 
        System.out.println("Default First one"); 
    } 
} 
interface Second 
{  
    default void display() 
    { 
        System.out.println("Default Second one"); 
    } 
}  

public class Diamond implements First,Second {
	public void display() 
    {  
        First.super.display(); 
        Second.super.display(); 
    } 


	public static void main(String[] args) {
		Diamond d = new Diamond(); 
        d.display(); 

	

	}

}
