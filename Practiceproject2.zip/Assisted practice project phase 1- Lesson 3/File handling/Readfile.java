package pk7;
import java.util.*; 
import java.nio.charset.StandardCharsets; 
import java.nio.file.*; 
import java.io.*; 


public class Readfile {
	public static List<String> readFileInList(String fn) 
	  { 
	  
	    List<String> l1 = Collections.emptyList(); 
	    try
	    { 
	      l1= Files.readAllLines(Paths.get(fn), StandardCharsets.UTF_8); 
	    } 
	  
	    catch (IOException e) 
	    { 
	      e.printStackTrace(); 
	    } 
	    return l1; 
	  } 


	public static void main(String[] args) {
		List l = readFileInList("c://Sample//textFile1.txt"); 
		  
	    Iterator<String> itr = l.iterator(); 
	    while (itr.hasNext()) 
	      System.out.println(itr.next()); 


	}

}
