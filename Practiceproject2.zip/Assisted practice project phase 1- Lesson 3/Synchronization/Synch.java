package pk3;

public class Synch {
    public void send(String s) 
    { 
        System.out.println("Sending\t"  + s ); 
        try
        { 
            Thread.sleep(1000); 
        } 
        catch (Exception e) 
        { 
            System.out.println("Thread  interrupted."); 
        } 
        System.out.println("\n" + s + "Sent"); 
    } 


}
