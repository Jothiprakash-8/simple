package pk3;

public class Synch2 {

	public static void main(String[] args) {
		Synch  s= new Synch(); 
        Synch1 S1 = new Synch1( " Hi " , s ); 
        Synch1 S2 = new Synch1( " Bye " , s ); 
        S1.start(); 
        S2.start(); 
        try
        { 
            S1.join(); 
            S2.join(); 
        } 
        catch(Exception e) 
        { 
            System.out.println("Interrupted"); 
        } 


	}

}
