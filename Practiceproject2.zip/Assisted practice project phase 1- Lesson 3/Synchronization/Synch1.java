package pk3;

public class Synch1 extends Thread {
	private String m1; 
    private Thread t; 
    Synch  s; 
    Synch1(String m,  Synch obj) 
    { 
        m1 = m; 
        s = obj; 
    } 
  
    public void run() 
    {  
        synchronized(s) 
        { 
            s.send(m1); 
        } 
    } 

}
