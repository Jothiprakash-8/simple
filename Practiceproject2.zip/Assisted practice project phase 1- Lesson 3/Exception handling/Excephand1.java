package pk6;

public class Excephand1 {

	public static void main(String[] args) {
		try{
			System.out.println("Starting of try block");
			
			throw new Excephand("This is My error Message");
		}
		catch(Excephand eh){
			System.out.println("This is Catch Block") ;
			System.out.println(eh) ;
		}


	}

}
