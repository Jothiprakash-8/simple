package pk6;

public class Excephand extends Exception {

	String s1;
	   Excephand(String s2) {
		s1=s2;
	   }
	   public String toString(){ 
		return ("Exception Occurred: "+s1) ;
	   }
	}

