package pk4;

public class Trycatchpgm {

	public static void main(String[] args) {
		int[] array = new int[10];
        try 
        {
            array[15] = 35;
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Array index is out of bounds here"); 
        }
        finally 
        {
            System.out.println("The array is of size: " + array.length);
        }


	}

}
