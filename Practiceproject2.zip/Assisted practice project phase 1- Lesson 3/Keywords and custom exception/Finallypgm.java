package pk5;

public class Finallypgm {

	public static void main(String[] args) {
		int x=100;
		int y=0;
		int z=0;
        try
        {
            z= x/y;
        }
        catch(ArithmeticException ae)
        {
            System.out.print("\nError : " + ae.getMessage());
        }
        finally
        {
            System.out.print("\nThe result is : " + z);
        }


	}

}
