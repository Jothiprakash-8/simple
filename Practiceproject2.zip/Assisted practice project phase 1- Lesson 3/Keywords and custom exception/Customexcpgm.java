package pk5;

public class Customexcpgm extends Exception {
	public 	Customexcpgm(String s) 
    { 
        super(s); 
    } 


}
