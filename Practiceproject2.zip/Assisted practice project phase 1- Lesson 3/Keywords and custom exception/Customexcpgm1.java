package pk5;

public class Customexcpgm1 {

	public static void main(String[] args) {
		try
        { 
            throw new Customexcpgm("hello"); 
        } 
        catch (Customexcpgm ce) 
        { 
            System.out.println("Good morning"); 
            System.out.println(ce.getMessage()); 
        } 


	}

}
