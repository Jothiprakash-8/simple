package pk5;

public class Throwpgm {

	public static void main(String[] args) {
		int x=50;
		int y=0;
		int z;

        try
        {
            if(y==0)        
                throw(new ArithmeticException(" We Can't divide by zero"));
            else
            {
                z = x/y;
                System.out.print("\n\tThe result is : " + z);
            }
        }
        catch(ArithmeticException ae)
        {
            System.out.print("\nError: " + ae.getMessage());
        }

        System.out.print("\nEnd of program");


	}

}
