package pk5;

public class Throwspgm {
	void Division() throws ArithmeticException
    {
        int a=75;
        int b=0;
        int c;
        c = a / b;
        System.out.print("\nThe result is: " + c);
    }

	public static void main(String[] args) {
		Throwspgm TP = new Throwspgm();
        try
       {
           TP.Division();
       }
       catch(ArithmeticException ae)
       {
           System.out.print("\nError : " + ae.getMessage());
       }
       System.out.print("\nEnd of program.");


	}

}
