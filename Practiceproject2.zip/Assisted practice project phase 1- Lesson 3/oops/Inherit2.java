package pk8;

public class Inherit2 {

	public static void main(String[] args) {
        Inherit1 mb = new Inherit1(5, 120, 30); 
        System.out.println(mb.toString());


	}

}
