package pk8;

public class New {

	public static void main(String[] args) {
		Abstractpgm ab = new Circle("Green", 2.5); 
        Abstractpgm ab1 = new Rectangle("Red", 2, 5);
        System.out.println(ab.toString()); 
        System.out.println(ab1.toString()); 


	}

}
