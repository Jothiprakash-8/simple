package pk8;

public class Rectangle extends Abstractpgm{
	double l; 
    double w; 
    public Rectangle(String c,double l,double w) 
    { 
        super(c); 
        System.out.println("Rectangle constructor called"); 
        this.l = l; 
        this.w = w; 
    } 
    @Override
    double area() 
    { 
        return l*w; 
    } 
    @Override
    public String toString() 
    { 
        return "Rectangle colour is " + super.c +  
                           "and area is : " + area(); 
    } 


}
