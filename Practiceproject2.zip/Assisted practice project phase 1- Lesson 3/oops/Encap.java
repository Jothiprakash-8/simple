package pk8;

public class Encap {
	private String Name; 
    private int Rollnumber; 
    private int Age;
    private String Place;
    public int getAge()  
    { 
      return Age; 
    } 
    public String getName()  
    { 
      return Name; 
    } 
    public int getRoll()  
    { 
       return Rollnumber; 
    } 
    public String getPlace()
    {
    	return Place;
    }
    public void setAge( int newAge) 
    { 
      Age = newAge; 
    } 
    public void setName(String newName) 
    { 
      Name = newName; 
    } 
    public void setRoll( int newRoll)  
    { 
      Rollnumber = newRoll; 
    } 
    public void setPlace(String newPlace)
    {
    	Place=newPlace;
    }


}
