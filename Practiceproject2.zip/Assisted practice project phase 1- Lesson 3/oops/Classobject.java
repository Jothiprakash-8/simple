package pk8;

public class Classobject {
	String firstname; 
    String lastname; 
    int age; 
    String place; 
    public Classobject(String firstname, String lastname, int age, String place) 
    { 
        this.firstname = firstname; 
        this.lastname =lastname; 
        this.age = age; 
        this.place =place; 
    } 
    public String getfName() 
    { 
        return firstname; 
    } 
    public String getlName() 
    { 
        return lastname; 
    } 
    public int getAge() 
    { 
        return age; 
    } 
    public String getPlace() 
    { 
        return place; 
    } 
    @Override
    public String toString() 
    { 
        return("Hi my firstname is "+ this.getfName()+ ".\nMy last name is " + this.getlName()+", " +"\nMy age is " + this.getAge() +" and \nMy place of living is "+ this.getPlace() + "."); 
    } 


	public static void main(String[] args) {
		Classobject cb = new Classobject("Ram","Charan", 25, "Hyderabad"); 
        System.out.println(cb.toString()); 

		

	}

}
