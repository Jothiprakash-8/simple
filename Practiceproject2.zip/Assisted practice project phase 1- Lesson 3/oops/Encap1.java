package pk8;

public class Encap1 {

	public static void main(String[] args) {
		Encap ec = new Encap(); 
        ec.setName("Vijay"); 
        ec.setAge(22); 
        ec.setRoll(99); 
        ec.setPlace("Hyderabad");
        System.out.println("My name: " + ec.getName()); 
        System.out.println("My age: " + ec.getAge()); 
        System.out.println("My rollnumber: " + ec.getRoll()); 
        System.out.println("My place of living  "+ec.getPlace());


	}

}
