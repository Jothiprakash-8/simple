package pk8;

 class Circle extends Abstractpgm{
	 double radius; 
	    public Circle(String c,double radius) 
	    { 
	        super(c); 
	        System.out.println("Circle constructor called"); 
	        this.radius = radius; 
	    }
	    @Override
	    double area() 
	    { 
	        return Math.PI * Math.pow(radius, 2); 
	    } 
	    @Override
	    public String toString() 
	    { 
	        return "Circle colour is " + super.c + "and area is : " + area(); 
	    } 

	

}
