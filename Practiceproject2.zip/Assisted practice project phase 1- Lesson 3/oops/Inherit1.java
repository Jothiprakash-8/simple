package pk8;

public class Inherit1 extends Inherit {
	public int sh; 
    public Inherit1(int g,int s,int h) 
    {  
        super(g, s); 
        sh = h; 
    }  
    public void setHeight(int a) 
    { 
        sh = a; 
    } 
    @Override
    public String toString() 
    { 
        return (super.toString()+ 
                "\nseat height is "+sh); 
    } 

}
