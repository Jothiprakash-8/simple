package pk8;

abstract class Abstractpgm {
	String c; 
    abstract double area(); 
    public abstract String toString(); 
    public Abstractpgm(String color) 
    { 
        System.out.println("Shape constructor called"); 
        this.c = c; 
    } 
    public String getColor() 
    { 
        return c; 
    } 

}
