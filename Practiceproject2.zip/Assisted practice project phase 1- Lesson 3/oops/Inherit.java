package pk8;

public class Inherit {
	public int g; 
    public int s; 
    public Inherit(int g, int s) 
    { 
        this.g = g; 
        this.s = s; 
    } 
    public void applyBrake(int d) 
    { 
        s -= d; 
    } 
    public void speedUp(int i) 
    { 
        s += i; 
    }  
    public String toString()  
    { 
        return("Gear " + g + "\n" + "speed of car is " + s); 
    }

}
