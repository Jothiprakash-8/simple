package pk1;

public class RunnableThread implements Runnable{
	 
    public static int a = 0;
    public RunnableThread(){
         
    }
    public void run() {
        while(RunnableThread.a <= 5){
            try{
                System.out.println("Expl Thread: "+(++RunnableThread.a));
                Thread.sleep(1000);
            } catch (InterruptedException ie) {
                System.out.println("Exception in thread: "+ie.getMessage());
            }
        }
    } 
    public static void main(String a[]){
        System.out.println("Starting Main Thread...");
        RunnableThread rt = new RunnableThread();
        Thread t = new Thread(rt);
        t.start();
        while(RunnableThread.a <= 5){
            try{
                System.out.println("Main Thread: "+(++RunnableThread.a));
                Thread.sleep(1000);
            } catch (InterruptedException ie){
                System.out.println("Exception in main thread: "+ie.getMessage());
            }
        }
        System.out.println("End of Main Thread...");
    }
}

