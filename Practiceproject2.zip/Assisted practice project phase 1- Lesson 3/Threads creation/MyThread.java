package pk1;

public class MyThread extends Thread {
	public void run()
 	{
  		System.out.println("concurrent thread started running now");
}


	public static void main(String[] args) {
		MyThread m = new  MyThread();
  		m.start();

	

	}

}
